﻿# Kamu dapat taruh script game mu di file ini.

# Deklarasikan gambar di bawah line ini, menggunakan pernyataan image.
# cnth. image eileen happy = "eileen_happy.png"

# Deklarasikan karakter yang digunakan di game.
define a = Character('Ayah Ratih', color="#c8ffc8")
define r = Character('Ratih', color="#c8ffc8")
define i = Character('Ibu Ratih', color="#c8ffc8")
define s = Character('Santika', color="#c8ffc8")
define k = Character('Kayla', color="#c8ffc8")
define d = Character('Darma', color="#c8ffc8")
define b = Character('Bellina', color="#c8ffc8")
define u = Character('Id', color="#c8ffc8")
define p = Character('Superego', color="#c8ffc8")
define e = Character('Bellina', color="#c8ffc8")
define l = Character('Luna', color="#c8ffc8")
define g = Character('Guru', color='#c8ffc8')

init python:
    # Memaksa seluruh tombol di dalam game (Main Menu, Preferences, Choice, dll)
    # untuk memutar suara ini saat diklik, tanpa peduli pengaturan options.rpy
    style.button.activate_sound = "audio/button_click.ogg"
    style.image_button.activate_sound = "audio/button_click.ogg"
    style.text_button.activate_sound = "audio/button_click.ogg"
    style.navigation_button.activate_sound = "audio/button_click.ogg"
    style.choice_button.activate_sound = "audio/click.ogg"

# Game dimulai disini:
# Deklarasi video sebagai sebuah image
label splashscreen:
    scene black
    show movie
    $ renpy.movie_cutscene("opening2.webm")
    return

label start:

    scene bg blck with dissolve
    play music "audio/baby_sound.mp3"
    scene ayah ibu:
        fit "cover"
        yalign 0.6
    a "Wah, anakku benar-benar sangat cantik."
    i "iya dong, anak kita emang cantik"
    a "kita beri nama.."
    hide ayah ibu
    scene ratih baby:
        fit "cover"
        yalign 0.5
    "RATIH"
    hide ratih baby
    stop music fadeout 1.0
    scene 1004:
        fit "cover"
        yalign 0.5
    "Saat Ratih berumur 9 Tahun dan ia sedang menonton sebuah drama di TV"
    hide 1004
    scene 1003:
        fit "cover"
        yalign 0.5
    "Ratih pun terkagum pada aktris dan ingin menjadi seorang aktris seperti artis yang memainkan peran di sebuah drama"
    hide 1003
    play music "audio/lulabi.mp3"
    scene 1002:
        fit "cover"
        yalign 0.5
    i "aduhh, cantiknyaa"
    stop music fadeout 1.0
    i "kamu mau jadi penyanyi ?"
    r "tidakk, aku lagi main akting dongg"
    "Sejak itu, Ratih pun menyukai bernyanyi dan bermain peran dan ia pun menganggap apa yang dia lakukan itu adalah hobinya"
    hide 1002
    scene teater bg
    show nyanyii:
        fit "cover"
        yalign 0.5
    "Ratih pun bertampil bermain peran di sekolah"
    hide nyanyii
    scene teater bg
    show santika jelek ratih:
        fit "cover"
        yalign 0.5
    "Ah, dia hanya beruntung saja dapat peran utama berkat kecantikan dia tapi cara berakting tuh b aja banget nggak sih ?!"
    hide santika jelek ratih
    scene teater bg
    show teman
    "Di saat sedang bertampil di panggung, Ratih tidak sengaja menguping perkataan jelek padanya"
    show ratih shock
    "..."
    
    "Sehabis bertampil dipanggung, Ratih pun mencoba menguping percakapan tentang dirinya"
    show ratih shock:
        alpha 0.8

    s "liat tuh Ratih. Aktingnya biasa aja, pikmi banget dia mah. Ngandelin modal cantik doang"

    s "Aku juga bisa lebih bagus dan lebih cantik daripada dia kalau ada kesempatan"
    

    menu:
        "Apakah Ratih perlu melawan teman yang suka mengejek?"
        
        "Ya! Lawan mereka!":
            jump ratih_melawan
            
        "Kabur sajalah! cari aman":
            jump ratih_kabur
    hide ratih shock
# Alur cerita jika memilih opsi 1A
label ratih_melawan:
    scene teater bg
    show melawan:
        fit "cover"
        yalign 0.5
    r "Cukup! Aku tidak akan membiarkan kalian mengejekku lagi!"
    "Ratih merasa sedikit lebih berani setelah mengutarakan perasaannya. Namun, teman pun tetap melawan tanpa alasan"
    s "apaaan sih kamu"
    "(ah.. gak mempan.. hatiku terasa sakit..)"
    hide melawan
    show ortu:
        fit "cover"
        yalign 0.5
    "Ratih pun capek dan bertemu dengan orang tua di luar backstage dan Ratih mau berbicara sesuatu tapi..."

    i "Ratih, tadi kamu bertampil dengan baik dan bagus tapi rasanya kurang menarik... apa yang terjadi padamu?"
    a "Iya bener, padahal kamu itu sudah berusaha dengan baik tapi kok aktingnya masih kurang? Ada apa denganmu??"
    
    "Ratih hanya terdiam dan menangis ketika ditanya"

    menu:
        "Apa perlu menjawab atau tidak?"

        "Ya, menjawab dengan minta maaf":
            jump ratih_menjawab
        
        "Tidak menjawab dan hanya mengangguk":
            jump ratih_tidakmenjawab
    
#Alur cerita jika memilih opsi 2A
label ratih_menjawab:
    r "A.. aku meminta maaf dan.. hanya gugup saja.."
    i "sudahlah, tidak apa apalah ayo pulang, ratih"
    hide teguran
    show mobil:
        fit "cover"
        yalign 0.5
    "Ratih pulang dengan penuh kecemasan dan melihat pemandangan dengan tatapan kosong"

    "Ego melihat dirinya dan merasa sedih dan penuh kekhawatiran"
    hide mobil
    jump transisi_chapter_2

#Alur cerita jika memilih opsi 2B
label ratih_tidakmenjawab:
    "Ratih hanya mengangguk dan tidak menjawab sama sekali"

    i "..."
    i "ayo pulang, sudah mau malam ini"
    show mobil:
        fit "cover"
        yalign 0.5
    "Ratih pulang dengan penuh kecemasan dan melihat pemandangan dengan tatapan kosong"

    "Ego melihat dirinya dan merasa sedih dan penuh kekhawatiran"
    hide mobil
    jump transisi_chapter_2

# Alur cerita jika memilih opsi 1B
label ratih_kabur:
    "Ratih menunduk dan berjalan cepat menjauhi kerumunan itu."
    r "Lebih baik aku pulang saja..."
    scene teater
    show ortu:
        fit "cover"
        yalign 0.5
    i "Ratih, tadi kamu bertampil dengan baik dan bagus tapi rasanya kurang menarik... apa yang terjadi padamu?"
    a "Iya bener, padahal kamu itu sudah berusaha dengan baik tapi kok aktingnya jelek dan tidak menang sama sekali ?"

    "Ratih hanya terdiam dan menangis ketika ditanya"

    menu:
        "Apa perlu menjawab atau tidak?"

        "Ya, menjawab dengan permintamaaf":
            jump ratih_menjawab1
        
        "Tidak menjawab dan hanya mengangguk":
            jump ratih_tidakmenjawab1
    
#Alur cerita jika memilih opsi 2A
label ratih_menjawab1:
    r "A.. aku meminta maaf dan.. hanya gugup saja.."
    i "sudahlah, ayo pulang tih"
    hide teguran
    show mobil:
        fit "cover"
        yalign 0.5
    "Ratih pulang dengan penuh kecemasan dan melihat pemandangan dengan tatapan kosong"

    "Ego melihat dirinya dan merasa sedih dan penuh kekhawatiran"
    hide mobil
    jump transisi_chapter_2

#Alur cerita jika memilih opsi 2B
label ratih_tidakmenjawab1:
    "Ratih hanya mengangguk dan tidak menjawab sama sekali"
    i "..."
    i "ayo pulang"
    show mobil:
        fit "cover"
        yalign 0.5
    "Ratih pulang dengan penuh kecemasan dan melihat pemandangan dengan tatapan kosong"

    "Ego melihat dirinya dan merasa sedih dan penuh kekhawatiran"
    hide mobil
    jump transisi_chapter_2

# Akhir dari Chapter 1
label transisi_chapter_2:
    scene black with dissolve
    window hide
    
    # Panggil screen dengan isi teks yang kamu mau
    call screen chapter_next_button("CHAPTER 2", "Gema Kecemasan")
    
    window show
    
    jump isi_chapter_2 # Melompat ke isi Chapter 2

label isi_chapter_2:
    scene klass:
        fit "cover"
    "Memasuki masa SMP, Ratih pun banyak berubah dari masa SD."

    scene melamun2

    "Ratih melamun pada pemandangan luar dan banyak pikiran"
    "Tiba-tiba Guru memanggil Ratih untuk membacakan buku karena Ratih tidak memperhatikan kelas"
    show expression Solid("#000000") as background_gelap:
        alpha 0.5
        size (1920,1080)
    show ratih kaget:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8 
    g "Ratih, kamu saja tidak memperhatikannya, bisakah kamu membaca buku halaman 16 ?"
    "Ratih berdiri tegang dan gugup karena rasa takut padanya. Ratih pun mencoba membacakan tapi jantungku terasa cepat dan tidak berhenti"
    r "Rasanya aku tidak kuat dan terasa sesak (dalam hati)"
    
    menu:
        "Perlu kabur atau tidak ?"

        "Kabur sajalah !!":
            jump ratih_kaburkelas

        "Tetap berusaha membacakan buku sebisanya":
            jump ratih_membaca
    hide ratih 4
    hide klass
#Alur cerita Chapter II opsi 1A
label ratih_kaburkelas:
    scene klass:
        fit "cover"
    play music "audio/laughing_crowd.mp3"
    "Kabur dari kelasnya dan ditertawain satu kelas"
    hide klass
    stop music fadeout 1.0
    scene kamar mandi:
        fit "cover"
        yalign 0.5
    "Ratih langsung berlari dan ia menangis bersembunyi di dalam kamar mandi"
    show kayla o:
        zoom 0.60  
        xalign 1.0  
        yalign 0.5 
    
    "Setelah kelas pun selesai, Kayla mengetuk pintu kamar mandi"
    k "hey, ratih. Are u okay ? kalo ada apa, langsung kasih tau padaku ya"
    show kayla i:
        zoom 0.60  
        xalign 1.0  
        yalign 0.5
    "Ratih pun keluar dari kamar mandinya"
    k "Gak apa apa ?"
    
    show ratih i:
        zoom 0.60   
        xalign 0.1  
        yalign 0.8 
        alpha 1.0

    show kayla i:
        zoom 0.60  
        xalign 1.0  
        yalign 0.5
        alpha 0.5

    r "Gapapa"
    show ratih i:
        zoom 0.60   
        xalign 0.1  
        yalign 0.8 
        alpha 0.5

    show kayla j:
        zoom 0.60  
        xalign 1.0  
        yalign 0.5
        alpha 1.0
    k "Yasudah, ayo ke kantin"
    hide ratih2
    hide kayla 2
    hide kamar mandi
    show koridor
    "Kayla dan Ratih pun pergi menuju kantin sambil menggandeng tangan"

    "Tiba-tiba seorang laki-laki menabrak secara tidak sengaja"
    show biru:
        zoom 0.60   
        xalign 1.0  
        yalign 0.5
        alpha 1.0
    r "aduhh..."
    hide biru
    show darma:
        zoom 0.65
        xalign 0.1  
        yalign 1.0
        alpha 1.0
    show hitam:
        zoom 0.60
        xalign 1.0
        yalign 0.5
        alpha 0.5
    d "eh, gapapa ? maafkan aku"
    show darma:
        zoom 0.65
        xalign 0.1  
        yalign 1.0
        alpha 0.5
    show hitam:
        zoom 0.60
        xalign 1.0
        yalign 0.5
        alpha 1.0
    r "eh, gapapa kok. ini salah saya..."
    show darma:
        zoom 0.65
        xalign 0.1  
        yalign 1.0
        alpha 1.0
    show hitam:
        zoom 0.60
        xalign 1.0
        yalign 0.5
        alpha 0.5
    d "nggakkk.. ini murni salah saya"
    hide koridor
    hide darma
    hide hitam
    scene ratih tidur:
        fit "cover"
    "Sekolah pun selesai, Ratih pulang dan beristirahat di rumah"
    "tiba-tiba..."
    "Ratih terbangun dan berada di dunia..."
    hide ratih tidur
    $ renpy.movie_cutscene("ratih_world.webm")
    show ratih mind world:
        fit "cover"
    "dunia tidak biasa, Ratih's Mind"
    show monster id:
        zoom 0.8
        xalign 1.0  
        yalign 0.8
    "Monster pun menyambut dan mengenalkan diri"
    u "Hey, Ratih !! kenalkan aku Monster Id"
    hide monster id
    "Monster Id menemani dan keliling dunia Ratih"
    "Tetiba Monster Id tidak sengaja menabrak properti Superego"
    show superego 1:
        zoom 0.8
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    p "Hey! kamu merusak propertiku!"
    show monster id:
        zoom 0.80   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    show superego:
        zoom 0.8
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    u "kamu aja menaruh di tempat sembarangan!"
    scene tengkaran
    "mereka pun mulai bertengkar, sedangkan Ratih melihat sesuatu yang gak biasa"
    hide tengkaran
    scene ratih mind world:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.9
        size (1920,1080)
    show belinaa quarter
    "bukankah itu ego dirinya ?"
    r "kenapa dia menatap aku ?"
    hide belinaa quarter
    hide ratih mind world
    scene black with dissolve
    scene ratih bangun:
        fit "cover"
    "Ratih pun terbangun"
    r "haa! kok sudah malam?"
    hide kamare ratih
    scene black with dissolve
    show belajar preseentasi
    "Esoknya, Ratih dan Kayla diberi tugas presentasi"
    "Ratih dan Kayla pun berlatih berpresentasi"
    "Ratih dan Kayla bersiap memulai mempresentasikan materi"
    "tapi...."
    scene presentasi
    "Ratih tiba-tiba mulai merasakan gugup"
    "Ia pun mulai berkeringat, tangannya mulai terasa dingin dan ia semakin sulit mendefinisikan perasaannya"

    $ renpy.movie_cutscene("heartbeats.webm")

    "terasa sesak dan sensasi nyeri pada dadanya"
    hide presentasi
    scene ratih kabur
    "anxiety pun melonjak naik, aku berlari dan bersembunyi"
    hide presentasi
    scene ratih kabur
    "begitu jadwal sekolah semua selesai dan dia pulang tanpa pamit kayla"
    scene rumah ratih:
        fit "cover"
    "Di rumah"
    show ayah di ruang tv
    "Tiba-tiba bapak mengomel Ratih karena diberitahu guru bahwa Ratih mendapatkan posisi 3 terbaik sekolah"
    a "kok gak dapet peringkat satu sih kamu ? biasanya kamu selalu menang, tapi gak papa sih. Lakukan yang terbaik ya"
    show ratih i:
        zoom 0.60
        xalign 0.1
        yalign 0.8
    r "maaf pah..."
    "Ratih tidak bisa berkata-kata tapi ia pun merasa posisi 3 itu sudah cukup"
    hide ratih i
    hide rumah ratih
    scene ratih capek:
        fit "cover"
    "Ia pun terdiam dan merenung dikamar menangis dan menelepon Kayla"
    hide ratih capek
    

    jump transisi_chapter_3

# Akhir dari Chapter II
label transisi_chapter_3:
    scene black with dissolve
    window hide
    
    # Panggil screen dengan isi teks yang kamu mau
    call screen chapter_next_button("CHAPTER III", "FINALE")
    
    window show
    
    jump isi_chapter_3 # Melompat ke isi Chapter 3

label isi_chapter_3:
    scene bg_eton_school with dissolve
    "memasuki SMA..."
    scene announcement:
        fit "cover"
    pause 1.0
    show kayla sma 1:
        zoom 0.75
        xalign 1.0  
        yalign 0.5
    k "kamu mau itu kah ?"
    hide kayla sma 1
    show show_poster at truecenter with easeinbottom:
        zoom 0.2 

    window hide
    pause
    window show
    "POSTER: Informasi terkait audisi akting..."
    show expression Solid("#000000") as background_gelap:
        alpha 0.9
        size (1920,1080)
    show ratih sma 1:
        zoom 0.60   
        xalign 0.5 
        yalign 0.8
    "Ratih teringat pada momen itu..."
    "Tapi..."
    hide ratih
    scene ratih mind world
    show superego:
        zoom 0.80   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    p "Apakah aku bisa mendorong dia agar bisa berani (tersenyum)"
    show superego:
        zoom 0.80   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show id 3:
        zoom 0.80
        xalign 0.1
        yalign 1.0
        alpha 1.0
    u "hei!! kamu ngapain sihh!! gausah maksa RATIH!! Kita pun belum tahu pada perasaannya!"
    show superego:
        zoom 0.80   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 3:
        zoom 0.80
        xalign 0.1
        yalign 1.0
        alpha 1.0
    "Id dan Superego mulai bertengkar demi melindungi ego Ratih"
    show superego 2:
        zoom 0.60   
        xalign 1.0  
        yalign 0.9
        alpha 0.8
    show id 2:
        zoom 0.60
        xalign 0.1
        yalign 0.9
        alpha 0.8
    show belina a:
        zoom 0.80
        xalign 0.5
        yalign 1.0
        alpha 1.0
    e "Sudahlah!! biarkan ratih yang memilih. Kita bergantung padanya"
    hide belina a
    hide id
    hide superego
    hide ratih mind world
    scene announcement:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.9
        size (1920,1080)
    show ratih:
        zoom 0.80
        xalign 0.5
        yalign 1.0
    "Ratih merasa mau berani melawan rasa cemas dalam dirinya, ia pun berpikir..."

    menu:
        "(Apa aku harus mendaftar pertunjukan ?)"

        "Ya, daftarlah!!":
            jump ratih_daftar

        "Tidak":
            jump ratih_menolak1
    hide announcement
    hide ratih
    #Alur cerita Chapter II opsi 1A
label ratih_daftar:
    scene announcement:
        fit "cover"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    r "baiklah, aku akan daftar"
    show ratih sma 3:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 2:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    "Kayla kaget mendengar"
    k "kamu gapapa ? emang kamu mau bertampil?"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    r "iyalah, ntar aja lihat kok"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 1:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    k "jangan dipaksa aja"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 1.0
    "darma melihat dan baru ingat itu Ratih"
    d "hey!"
    hide kayla 3
    hide darma 2
    hide ratih 9
    "darma melihat sebuah poster pertunjukan"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 1.0
    d "ah! kamu mau daftar itu ? ayo, ini kesempatan bagus buat kamu, tih"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    show kayla sma 1:
        zoom 0.60
        xalign 0.1
        yalign 0.7
        alpha 1.0
    show darma 10:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 0.5
    k "aku duluan yaa"
    hide kayla sma 1
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "oh iyaaa, dadah"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "eng..."
    r "(menghela napas) baiklah, aku daftar. Aku pernah tampil sejak SD"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "wahhh"
    d "Jadi, kamu pernah jadi aktris sebelumnya ?"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "hmm... bukan gitu.. tapi pernah ada sesuatu hal saja"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    "darma tiba-tiba terhenti"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "oh, maafkan aku terbawa suasana... aku gatau.."
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "EH eh, enggak nggak sih aman-aman kok cuma aku ingin tampil lagi buat nantangin sih"
    r "baru2 ini aku sadar punya kecemasan sosial.."
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "kecemasan?"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "ya pokoknya itulah (tidak bisa bercerita)"
    hide ratih sma 1
    hide darma 10
    scene eton teater:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.4
        size (1920,1080)
    show ratih 5:
        zoom 0.60   
        xalign 0.8  
        yalign 1.0
        alpha 1.0
    show darma 11:
        zoom 0.72   
        xalign 0.4 
        yalign 1.0
        alpha 1.0
    "Ratih dan Darma mendaftar dirinya di studio teater"
    hide darma 11
    hide ratih 5
    hide eton teater
    scene ratih mind world
    show superego 2:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 2:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    show belina 2:
        zoom 0.8
        xalign 0.5
        yalign 1.0
        alpha 1.0
    "Id, Superego, dan Bellina kaget melihatnya"
    show superego 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    show belina 2:
        zoom 0.8
        xalign 0.5
        yalign 1.0
        alpha 1.0
    e "ini.. ini sungguh langka ! ayo ayo ayoyo bantu ratih semangat"
    scene pelukan
    k "aku sungguh bahagia betapa kamu berani melangkah satu per satu"
    k "RATIH!!! (ia langsung berpeluk dengan Ratih)"
    r "eh ehh berat tau"
    scene black with dissolve
    "Kayla membantu dan menyemangat Ratih berlatih jauh sebelum hari-h"
    scene ratih di luar
    r "terima kasih, kamu (idolaku) bener-bener bikin aku motivasi melawan rasa takut"
    "tiba-tiba ada seseorang menyenggol aku"
    show santika senggool
    s "hey, kamu ratih bukan ? (melihat Ratih sekeliling)"
    show expression Solid("#000000") as background_gelap:
        alpha 0.3
        size (1920,1080)
    show ratih sma 1 zorder 5:
        zoom 0.60   
        xalign 1.0
        yalign 0.8
        alpha 1.0
    r "(ah, si bully ini lagi)"
    "jantungku mulai berdegub kencang, rasa cemas meledak"
    hide background_gelap
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0 
        yalign 0.8
        alpha 0.5
    s "Lho, beneran Ratih ternyata! Kok sombong banget sekarang? Dipanggil malah diem aja kayak patung. Masih penakut kayak dulu ya?"
    show expression Solid("#000000") as background_gelap:
        alpha 0.3
        size (1920,1080)
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0
        yalign 0.8
        alpha 1.0
    r "(Menarik napas panjang, mencoba menenangkan diri) 
    Aku nggak sombong, cuma lagi nggak mau diganggu."
    hide background_gelap
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    s "Cuma mau menyapa aja. Tapi liat muka kamu yang pucat gitu... lucu ya, ternyata nggak ada yang berubah dari kamu. Masih gampang banget dibikin gemeteran."
    hide ratih
    hide santika senggool
    scene ratih sulit
    r "(aku sulit mengontrol emosi dan jantungku gak berhenti.. deg-degan)"
    hide ratih sulit
    $ renpy.movie_cutscene("heartbeats.webm")
    scene belina marah
    e "perasaan ratih pun sakit banget.."
    e "SUPEREGO dan ID bantu Ratih keluar dari sini!!"
    show expression Solid("#000000") as background_gelap:
        alpha 0.6
        size (1920,1080)
    show superego 1:
        zoom 0.8
        xalign 1.0
        yalign 0.9
    show id 3:
        zoom 0.8
        xalign 0.1
        yalign 0.8
    "SIAPP !!!"
    hide belina marah
    hide superego 1
    hide id 3
    show hitam3:
        fit "cover"
    r "(kabur)"
    play music "audio/tertawa.ogg"
    s "(tertawa)"
    hide santika senggool
    hide hitam3
    stop music fadeout 1.0
    scene ratih syok
    "dikamarnya..."
    "Ratih menangis melulu, rasanya kek ditusuk.."
    scene black with dissolve
    scene ratih mind world:
        fit "cover"
    e "ada apa ?"
    show heartwarm:
        fit "cover"
    r "gatau sih..."
    hide heartwarm
    scene belina tenang
    e "gak apa apa, ambil napas dulu.."
    show expression Solid("#000000") as background_gelap:
        alpha 0.8
        size (1920,1080)
    show superego 2:
        zoom 0.7
        xalign 1.0
        yalign 1.0
    p "apa dia lg down?"
    show id 3:
        zoom 0.7
        xalign 0.1
        yalign 1.0
    u "iyalah, masa km buta?"
    hide background_gelap
    hide belina
    hide ratih mind world
    scene black with dissolve
    scene eton teater:
        fit "cover"
    "Hari H pelaksanaan audisi dimulai"
    scene black with dissolve
    $ renpy.movie_cutscene("endinga.webm")
    scene ratih berat
    r "aku berani..."
    r "tapi rasanya berat sekali..."
    k "gapapa, pelan-pelan saja, stau per satu langkah saja.."
    r "..."
    hide ratih berat 
    scene ortu2
    i "ratih.. kamu sudah bisa berani.."
    a "uh... selamat?"
    a "selamat, nak. Sebelumnya maafkan ayah jika ada.."
    a "erm... tidak memerhatikanmu?"
    show expression Solid("#000000") as background_gelap:
        alpha 0.5
        size (1920,1080)
    show ratih end:
        zoom 0.7
        xalign 1.0
        yalign 1.0
    r "pah mah... terima kasih... (peluk)"
    r "gapapa sih, pah.."
    hide ratih end
    hide ortu2
    scene black with dissolve
    scene final1
    "Terima kasih sudah menjaga dan melindungi ego, Luna"
    scene final2
    "Hope you'd never give up"
    scene black with dissolve
    return
    

label ratih_menolak:
    hide background_gelap
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 1.0
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    r "gak ah, takut"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 1:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    k "jangan dipaksa aja"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 1.0
    "darma melihat dan baru ingat itu Ratih"
    d "hey!"
    hide kayla 3
    hide darma 2
    hide ratih 9
    "darma melihat sebuah poster pertunjukan"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 1.0
    d "ah! kamu mau daftar itu ? ayo, ini kesempatan bagus buat kamu, tih"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    show kayla sma 1:
        zoom 0.60
        xalign 0.1
        yalign 0.7
        alpha 1.0
    show darma 10:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 0.5
    k "aku duluan yaa"
    hide kayla sma 1
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "oh iyaaa, dadah"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "eng..."
    r "(menghela napas) baiklah, aku daftar. Aku pernah tampil sejak SD"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "wahhh"
    d "Jadi, kamu pernah jadi aktris sebelumnya ?"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "hmm... bukan gitu.. tapi pernah ada sesuatu hal saja"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    "darma tiba-tiba terhenti"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "oh, maafkan aku terbawa suasana... aku gatau.."
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "EH eh, enggak nggak sih aman-aman kok cuma aku ingin tampil lagi buat nantangin sih"
    r "baru2 ini aku sadar punya kecemasan sosial.."
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "kecemasan?"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "ya pokoknya itulah (tidak bisa bercerita)"
    hide ratih sma 1
    hide darma 10
    scene eton teater:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.4
        size (1920,1080)
    show ratih 5:
        zoom 0.60   
        xalign 0.8  
        yalign 1.0
        alpha 1.0
    show darma 11:
        zoom 0.72   
        xalign 0.4 
        yalign 1.0
        alpha 1.0
    "Ratih dan Darma mendaftar dirinya di studio teater"
    hide darma 11
    hide ratih 5
    hide eton teater
    scene ratih mind world
    show superego 2:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 2:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    show belina 2:
        zoom 0.8
        xalign 0.5
        yalign 1.0
        alpha 1.0
    "Id, Superego, dan Bellina kaget melihatnya"
    show superego 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    show belina 2:
        zoom 0.8
        xalign 0.5
        yalign 1.0
        alpha 1.0
    e "ini.. ini sungguh langka ! ayo ayo ayoyo bantu ratih semangat"
    scene pelukan
    k "aku sungguh bahagia betapa kamu berani melangkah satu per satu"
    k "RATIH!!! (ia langsung berpeluk dengan Ratih)"
    r "eh ehh berat tau"
    scene black with dissolve
    "Kayla membantu dan menyemangat Ratih berlatih jauh sebelum hari-h"
    scene ratih di luar
    r "terima kasih, kamu (idolaku) bener-bener bikin aku motivasi melawan rasa takut"
    "tiba-tiba ada seseorang menyenggol aku"
    show santika senggool
    s "hey, kamu ratih bukan ? (melihat Ratih sekeliling)"
    show expression Solid("#000000") as background_gelap:
        alpha 0.3
        size (1920,1080)
    show ratih sma 1 zorder 5:
        zoom 0.60   
        xalign 1.0
        yalign 0.8
        alpha 1.0
    r "(ah, si bully ini lagi)"
    "jantungku mulai berdegub kencang, rasa cemas meledak"
    hide background_gelap
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0 
        yalign 0.8
        alpha 0.5
    s "Lho, beneran Ratih ternyata! Kok sombong banget sekarang? Dipanggil malah diem aja kayak patung. Masih penakut kayak dulu ya?"
    show expression Solid("#000000") as background_gelap:
        alpha 0.3
        size (1920,1080)
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0
        yalign 0.8
        alpha 1.0
    r "(Menarik napas panjang, mencoba menenangkan diri) 
    Aku nggak sombong, cuma lagi nggak mau diganggu."
    hide background_gelap
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    s "Cuma mau menyapa aja. Tapi liat muka kamu yang pucat gitu... lucu ya, ternyata nggak ada yang berubah dari kamu. Masih gampang banget dibikin gemeteran."
    hide ratih
    hide santika senggool
    scene ratih sulit
    r "(aku sulit mengontrol emosi dan jantungku gak berhenti.. deg-degan)"
    hide ratih sulit
    $ renpy.movie_cutscene("heartbeats.webm")
    scene belina marah
    e "perasaan ratih pun sakit banget.."
    e "SUPEREGO dan ID bantu Ratih keluar dari sini!!"
    show expression Solid("#000000") as background_gelap:
        alpha 0.6
        size (1920,1080)
    show superego 1:
        zoom 0.8
        xalign 1.0
        yalign 0.9
    show id 3:
        zoom 0.8
        xalign 0.1
        yalign 0.8
    "SIAPP !!!"
    hide belina marah
    hide superego 1
    hide id 3
    show hitam3:
        fit "cover"
    r "(kabur)"
    play music "audio/tertawa.ogg"
    s "(tertawa)"
    hide santika senggool
    hide hitam3
    stop music fadeout 1.0
    scene ratih syok
    "dikamarnya..."
    "Ratih menangis melulu, rasanya kek ditusuk.."
    scene black with dissolve
    scene ratih mind world:
        fit "cover"
    e "ada apa ?"
    show heartwarm:
        fit "cover"
    r "gatau sih..."
    hide heartwarm
    scene belina tenang
    e "gak apa apa, ambil napas dulu.."
    show expression Solid("#000000") as background_gelap:
        alpha 0.8
        size (1920,1080)
    show superego 2:
        zoom 0.7
        xalign 1.0
        yalign 1.0
    p "apa dia lg down?"
    show id 3:
        zoom 0.7
        xalign 0.1
        yalign 1.0
    u "iyalah, masa km buta?"
    hide background_gelap
    hide belina
    hide ratih mind world
    scene black with dissolve
    scene eton teater:
        fit "cover"
    "Hari H pelaksanaan audisi dimulai"
    scene black with dissolve
    $ renpy.movie_cutscene("endinga.webm")
    scene ratih berat
    r "aku berani..."
    r "tapi rasanya berat sekali..."
    k "gapapa, pelan-pelan saja, stau per satu langkah saja.."
    r "..."
    hide ratih berat 
    scene ortu2
    i "ratih.. kamu sudah bisa berani.."
    a "uh... selamat?"
    a "selamat, nak. Sebelumnya maafkan ayah jika ada.."
    a "erm... tidak memerhatikanmu?"
    show expression Solid("#000000") as background_gelap:
        alpha 0.5
        size (1920,1080)
    show ratih end:
        zoom 0.7
        xalign 1.0
        yalign 1.0
    r "pah mah... terima kasih... (peluk)"
    r "gapapa sih, pah.."
    hide ratih end
    hide ortu2
    scene black with dissolve
    scene final1
    "Terima kasih sudah menjaga dan melindungi ego, Luna"
    scene final2
    "Hope you'd never give up"
    scene black with dissolve
    return
#ini BELUM










#Alur cerita Chapter II opsi 1B
label ratih_membaca:
    scene melamun2:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.7
        size (1920,1080)
    show hitam:
        zoom 0.6
        xalign 0.5
        yalign 1.0
    "Saat Ratih mencoba, tiba-tiba Kayla memintaku duduk dan menggantikannya membaca buku."
    hide hitam
    show kayla o:
        zoom 0.70  
        xalign 1.0  
        yalign 0.5
    k "hey, biar aku yang baca saja, kamu duduk saja."
    hide kayla o
    scene kuatir:
        fit "cover"
    "Aku pun mengangguk saja dan duduk dengan penuh khawatir"
    "Setelah beberapa menit yang berlalu"
    hide kuatir
    scene gapapa:
        fit "cover"
        yalign 0.4
    k "kamu gapapa ? kalau ada apa, bilang saja ke aku ya"
    r "a-aku gak apa apa kok, kenapa ?"
    k "baiklah, mau ke kantin ?"
    hide gapapa
    show koridor
    "Ratih mengangguk dan berdua pun pergi menuju kantin sambil menggandeng tangan"

    "Tiba-tiba seorang laki-laki menabrak secara tidak sengaja"
    show biru:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    r "aduhh..."
    hide biru
    show darma:
        zoom 0.65
        xalign 0.1  
        yalign 1.0
        alpha 1.0
    show hitam:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    d "eh, gapapa ? maafkan aku"
    show darma:
        zoom 0.65
        xalign 0.1  
        yalign 1.0
        alpha 0.5
    show hitam:
        zoom 0.60
        xalign 1.0
        yalign 0.5
        alpha 1.0
    r "eh, gapapa kok. ini salah saya..."
    show darma:
        zoom 0.65
        xalign 0.1  
        yalign 1.0
        alpha 1.0
    show hitam:
        zoom 0.60
        xalign 1.0
        yalign 0.5
        alpha 0.5
    d "nggakkk.. ini murni salah saya"
    hide koridor
    hide darma
    hide hitam
    #INI UNTUK BELUM
    show ratih tidur:
        fit "cover"
    "Sekolah pun selesai, Ratih pulang dan beristirahat di rumah"
    "tiba-tiba..."
    "Ratih terbangun dan berada di dunia..."
    hide ratih tidur
    $ renpy.movie_cutscene("ratih_world.webm")
    show ratih mind world:
        fit "cover"
    "dunia tidak biasa, Ratih's Mind"
    show monster id:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
    "Monster pun menyambut dan mengenalkan diri"
    u "Hey, Ratih !! kenalkan aku Monster Id"
    hide monster id
    "Monster Id menemani dan keliling dunia Ratih"
    "Tetiba Monster Id tidak sengaja menabrak properti Superego"
    show superego 1:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 1.0
    p "Hey! kamu merusak propertiku!"
    show monster id:
        zoom 0.60   
        xalign 0.1 
        yalign 0.8
        alpha 1.0
    show superego:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    u "kamu aja menaruh di tempat sembarangan!"
    scene tengkaran
    "mereka pun mulai bertengkar, sedangkan Ratih melihat sesuatu yang gak biasa"
    hide tengkaran
    scene ratih mind world:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.9
        size (1920,1080)
    show belinaa quarter
    "bukankah itu ego dirinya?"
    r "kenapa dia menatap aku ?"
    hide belina quarter
    hide ratih mind world
    scene black with dissolve
    scene ratih bangun:
        fit "cover"
    "Ratih pun terbangun"
    r "haa! kok sudah malam?"
    hide ratih bangun
    scene black with dissolve
    show belajar preseentasi
    "Esoknya, Ratih dan Kayla diberi tugas presentasi"
    "Ratih dan Kayla pun berlatih berpresentasi"
    "Ratih dan Kayla bersiap memulai mempresentasikan materi"
    "tapi...."
    scene presentasi
    "Ratih tiba-tiba mulai merasakan gugup"
    "Ia pun mulai berkeringat, tangannya mulai terasa dingin dan ia semakin sulit mendefinisikan perasaannya"

    $ renpy.movie_cutscene("heartbeats.webm")

    "terasa sesak dan sensasi nyeri pada dadanya"
    hide presentasi
    scene ratih kabur
    "anxiety pun melonjak naik, aku berlari dan bersembunyi"
    hide presentasi
    scene ratih kabur
    "begitu jadwal sekolah semua selesai dan dia pulang tanpa pamit kayla"
    scene rumah ratih:
        fit "cover"
    "Di rumah"
    show ayah di ruang tv
    "Tiba-tiba bapak mengomel Ratih karena diberitahu guru bahwa Ratih mendapatkan posisi 3 terbaik sekolah"
    a "kok gak dapet peringkat satu sih kamu ? biasanya kamu selalu menang, tapi gak papa sih. Lakukan yang terbaik ya"
    show ratih i:
        zoom 0.60
        xalign 0.1
        yalign 0.8
    r "maaf pah..."
    "Ratih tidak bisa berkata-kata tapi ia pun merasa posisi 3 itu sudah cukup"
    hide ratih i
    hide rumah ratih
    scene ratih capek:
        fit "cover"
    "Ia pun terdiam dan merenung dikamar menangis dan menelepon Kayla"
    hide ratih capek
    

    jump transisi_chapter_31

# Akhir dari Chapter II
label transisi_chapter_31:
    scene black with dissolve
    window hide
    
    # Panggil screen dengan isi teks yang kamu mau
    call screen chapter_next_button("CHAPTER III", "FINALE")
    
    window show
    
    jump isi_chapter_32 # Melompat ke isi Chapter 3

label isi_chapter_32:
    scene bg_eton_school with dissolve
    "memasuki SMA..."
    scene announcement:
        fit "cover"
    pause 1.0
    show kayla sma 1:
        zoom 0.75
        xalign 1.0  
        yalign 0.5
    k "kamu mau itu kah ?"
    hide kayla sma 2
    show show_poster at truecenter with easeinbottom:
        zoom 0.2 

    window hide
    pause
    window show
    "POSTER: Informasi terkait audisi akting..."
    show ratih:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
    "Ratih teringat pada momen itu..."
    "Tapi..."
    hide ratih
    scene ratih mind world
    show superego:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    p "Apakah aku bisa mendorong dia agar bisa berani (tersenyum)"
    show superego:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show monster id:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    u "hei!! kamu ngapain sihh!! gausah maksa RATIH!! Kita pun belum tahu pada perasaannya!"
    show superego:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show monster id:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    "Id dan Superego mulai bertengkar demi melindungi ego Ratih"
    show superego:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show monster id:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show belina a:
        zoom 0.80
        xalign 0.5
        yalign 1.0
        alpha 1.0
    e "Sudahlah!! biarkan ratih yang memilih. Kita bergantung padanya"
    hide belina
    hide id
    hide superego
    hide ratih mind world
    scene announcement:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.9
        size (1920,1080)
    show ratih:
        zoom 0.80
        xalign 0.5
        yalign 1.0
    "Ratih merasa mau berani melawan rasa cemas dalam dirinya, ia pun berpikir..."
    menu:
        "(Apa aku harus mendaftar pertunjukan ?)"

        "Ya, daftarlah!!":
            jump ratih_daftar1

        "Tidak":
            jump ratih_menolak
    hide ratih
    hide announcement
    #Alur cerita Chapter II opsi 1A
label ratih_daftar1:
    scene announcement:
        fit "cover"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    r "baiklah, aku akan daftar"
    show ratih sma 3:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 2:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    "Kayla kaget mendengar"
    k "kamu gapapa ? emang kamu mau bertampil?"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    r "iyalah, ntar aja lihat kok"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 1:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    k "jangan dipaksa aja"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 1.0
    "darma melihat dan baru ingat itu Ratih"
    d "hey!"
    hide kayla 3
    hide darma 2
    hide ratih 9
    "darma melihat sebuah poster pertunjukan"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 1.0
    d "ah! kamu mau daftar itu ? ayo, ini kesempatan bagus buat kamu, tih"
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    show kayla sma 1:
        zoom 0.60
        xalign 0.1
        yalign 0.7
        alpha 1.0
    show darma 10:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 0.5
    k "aku duluan yaa"
    hide kayla sma 1
    show ratih 5:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "oh iyaaa, dadah"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "eng..."
    r "(menghela napas) baiklah, aku daftar. Aku pernah tampil sejak SD"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "wahhh"
    d "Jadi, kamu pernah jadi aktris sebelumnya ?"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "hmm... bukan gitu.. tapi pernah ada sesuatu hal saja"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    "darma tiba-tiba terhenti"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "oh, maafkan aku terbawa suasana... aku gatau.."
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "EH eh, enggak nggak sih aman-aman kok cuma aku ingin tampil lagi buat nantangin sih"
    r "baru2 ini aku sadar punya kecemasan sosial.."
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "kecemasan?"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "ya pokoknya itulah (tidak bisa bercerita)"
    hide ratih sma 1
    hide darma 10
    scene eton teater:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.4
        size (1920,1080)
    show ratih 5:
        zoom 0.60   
        xalign 0.8  
        yalign 1.0
        alpha 1.0
    show darma 11:
        zoom 0.72   
        xalign 0.4 
        yalign 1.0
        alpha 1.0
    "Ratih dan Darma mendaftar dirinya di studio teater"
    hide darma 11
    hide ratih 5
    hide eton teater
    scene ratih mind world
    show superego 2:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 2:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    show belina 2:
        zoom 0.8
        xalign 0.5
        yalign 1.0
        alpha 1.0
    "Id, Superego, dan Bellina kaget melihatnya"
    show superego 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    show belina 2:
        zoom 0.8
        xalign 0.5
        yalign 1.0
        alpha 1.0
    e "ini.. ini sungguh langka ! ayo ayo ayoyo bantu ratih semangat"
    scene pelukan
    k "aku sungguh bahagia betapa kamu berani melangkah satu per satu"
    k "RATIH!!! (ia langsung berpeluk dengan Ratih)"
    r "eh ehh berat tau"
    scene black with dissolve
    "Kayla membantu dan menyemangat Ratih berlatih jauh sebelum hari-h"
    scene ratih di luar
    r "terima kasih, kamu (idolaku) bener-bener bikin aku motivasi melawan rasa takut"
    "tiba-tiba ada seseorang menyenggol aku"
    show santika senggool
    s "hey, kamu ratih bukan ? (melihat Ratih sekeliling)"
    show expression Solid("#000000") as background_gelap:
        alpha 0.3
        size (1920,1080)
    show ratih sma 1 zorder 5:
        zoom 0.60   
        xalign 1.0
        yalign 0.8
        alpha 1.0
    r "(ah, si bully ini lagi)"
    "jantungku mulai berdegub kencang, rasa cemas meledak"
    hide background_gelap
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0 
        yalign 0.8
        alpha 0.5
    s "Lho, beneran Ratih ternyata! Kok sombong banget sekarang? Dipanggil malah diem aja kayak patung. Masih penakut kayak dulu ya?"
    show expression Solid("#000000") as background_gelap:
        alpha 0.3
        size (1920,1080)
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0
        yalign 0.8
        alpha 1.0
    r "(Menarik napas panjang, mencoba menenangkan diri) 
    Aku nggak sombong, cuma lagi nggak mau diganggu."
    hide background_gelap
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    s "Cuma mau menyapa aja. Tapi liat muka kamu yang pucat gitu... lucu ya, ternyata nggak ada yang berubah dari kamu. Masih gampang banget dibikin gemeteran."
    hide ratih
    hide santika senggool
    scene ratih sulit
    r "(aku sulit mengontrol emosi dan jantungku gak berhenti.. deg-degan)"
    hide ratih sulit
    $ renpy.movie_cutscene("heartbeats.webm")
    scene belina marah
    e "perasaan ratih pun sakit banget.."
    e "SUPEREGO dan ID bantu Ratih keluar dari sini!!"
    show expression Solid("#000000") as background_gelap:
        alpha 0.6
        size (1920,1080)
    show superego 1:
        zoom 0.8
        xalign 1.0
        yalign 0.9
    show id 3:
        zoom 0.8
        xalign 0.1
        yalign 0.8
    "SIAPP !!!"
    hide belina marah
    hide superego 1
    hide id 3
    show hitam3:
        fit "cover"
    r "(kabur)"
    play music "audio/tertawa.ogg"
    s "(tertawa)"
    hide santika senggool
    hide hitam3
    stop music fadeout 1.0
    scene ratih syok
    "dikamarnya..."
    "Ratih menangis melulu, rasanya kek ditusuk.."
    scene black with dissolve
    scene ratih mind world:
        fit "cover"
    e "ada apa ?"
    show heartwarm:
        fit "cover"
    r "gatau sih..."
    hide heartwarm
    scene belina tenang
    e "gak apa apa, ambil napas dulu.."
    show expression Solid("#000000") as background_gelap:
        alpha 0.8
        size (1920,1080)
    show superego 2:
        zoom 0.7
        xalign 1.0
        yalign 1.0
    p "apa dia lg down?"
    show id 3:
        zoom 0.7
        xalign 0.1
        yalign 1.0
    u "iyalah, masa km buta?"
    hide background_gelap
    hide belina
    hide ratih mind world
    scene black with dissolve
    scene eton teater:
        fit "cover"
    "Hari H pelaksanaan audisi dimulai"
    scene black with dissolve
    $ renpy.movie_cutscene("endinga.webm")
    scene ratih berat
    r "aku berani..."
    r "tapi rasanya berat sekali..."
    k "gapapa, pelan-pelan saja, stau per satu langkah saja.."
    r "..."
    hide ratih berat 
    scene ortu2
    i "ratih.. kamu sudah bisa berani.."
    a "uh... selamat?"
    a "selamat, nak. Sebelumnya maafkan ayah jika ada.."
    a "erm... tidak memerhatikanmu?"
    show expression Solid("#000000") as background_gelap:
        alpha 0.5
        size (1920,1080)
    show ratih end:
        zoom 0.7
        xalign 1.0
        yalign 1.0
    r "pah mah... terima kasih... (peluk)"
    r "gapapa sih, pah.."
    hide ratih end
    hide ortu2
    scene black with dissolve
    scene final1
    "Terima kasih sudah menjaga dan melindungi ego, Luna"
    scene final2
    "Hope you'd never give up"
    scene black with dissolve
    return
    

label ratih_menolak1:
    hide background_gelap
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 1.0
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    r "gak ah, takut"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 1:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    k "jangan dipaksa aja"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 1.0
    "darma melihat dan baru ingat itu Ratih"
    d "hey!"
    hide kayla 3
    hide darma 2
    hide ratih 9
    "darma melihat sebuah poster pertunjukan"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show kayla sma 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 1.0
    d "ah! kamu mau daftar itu ? ayo, ini kesempatan bagus buat kamu, tih"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    show kayla sma 1:
        zoom 0.60
        xalign 0.1
        yalign 0.7
        alpha 1.0
    show darma 10:
        zoom 0.7  
        xalign 0.52
        yalign 1.0
        alpha 0.5
    k "aku duluan yaa"
    hide kayla sma 1
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "oh iyaaa, dadah"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "eng..."
    r "(menghela napas) baiklah, aku daftar. Aku pernah tampil sejak SD"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 11:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "wahhh"
    d "Jadi, kamu pernah jadi aktris sebelumnya ?"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.70   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "hmm... bukan gitu.. tapi pernah ada sesuatu hal saja"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    "darma tiba-tiba terhenti"
    show ratih 12:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "oh, maafkan aku terbawa suasana... aku gatau.."
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "EH eh, enggak nggak sih aman-aman kok cuma aku ingin tampil lagi buat nantangin sih"
    r "baru2 ini aku sadar punya kecemasan sosial.."
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 0.5
    show darma 12:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 1.0
    d "kecemasan?"
    show ratih sma 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show darma 10:
        zoom 0.72   
        xalign 0.1 
        yalign 1.0
        alpha 0.5
    r "ya pokoknya itulah (tidak bisa bercerita)"
    hide ratih sma 1
    hide darma 10
    scene eton teater:
        fit "cover"
    show expression Solid("#000000") as background_gelap:
        alpha 0.4
        size (1920,1080)
    show ratih 5:
        zoom 0.60   
        xalign 0.8  
        yalign 1.0
        alpha 1.0
    show darma 11:
        zoom 0.72   
        xalign 0.4 
        yalign 1.0
        alpha 1.0
    "Ratih dan Darma mendaftar dirinya di studio teater"
    hide darma 11
    hide ratih 5
    hide eton teater
    scene ratih mind world
    show superego 2:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 2:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    show belina 2:
        zoom 0.8
        xalign 0.5
        yalign 1.0
        alpha 1.0
    "Id, Superego, dan Bellina kaget melihatnya"
    show superego 1:
        zoom 0.60   
        xalign 1.0  
        yalign 1.0
        alpha 1.0
    show id 3:
        zoom 0.60
        xalign 0.1
        yalign 1.0
        alpha 1.0
    show belina 2:
        zoom 0.8
        xalign 0.5
        yalign 1.0
        alpha 1.0
    e "ini.. ini sungguh langka ! ayo ayo ayoyo bantu ratih semangat"
    scene pelukan
    k "aku sungguh bahagia betapa kamu berani melangkah satu per satu"
    k "RATIH!!! (ia langsung berpeluk dengan Ratih)"
    r "eh ehh berat tau"
    scene black with dissolve
    "Kayla membantu dan menyemangat Ratih berlatih jauh sebelum hari-h"
    scene ratih di luar
    r "terima kasih, kamu (idolaku) bener-bener bikin aku motivasi melawan rasa takut"
    "tiba-tiba ada seseorang menyenggol aku"
    show santika senggool
    s "hey, kamu ratih bukan ? (melihat Ratih sekeliling)"
    show expression Solid("#000000") as background_gelap:
        alpha 0.3
        size (1920,1080)
    show ratih sma 1 zorder 5:
        zoom 0.60   
        xalign 1.0
        yalign 0.8
        alpha 1.0
    r "(ah, si bully ini lagi)"
    "jantungku mulai berdegub kencang, rasa cemas meledak"
    hide background_gelap
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0 
        yalign 0.8
        alpha 0.5
    s "Lho, beneran Ratih ternyata! Kok sombong banget sekarang? Dipanggil malah diem aja kayak patung. Masih penakut kayak dulu ya?"
    show expression Solid("#000000") as background_gelap:
        alpha 0.3
        size (1920,1080)
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0
        yalign 0.8
        alpha 1.0
    r "(Menarik napas panjang, mencoba menenangkan diri) 
    Aku nggak sombong, cuma lagi nggak mau diganggu."
    hide background_gelap
    show ratih 12 zorder 5:
        zoom 0.60   
        xalign 1.0  
        yalign 0.8
        alpha 0.5
    s "Cuma mau menyapa aja. Tapi liat muka kamu yang pucat gitu... lucu ya, ternyata nggak ada yang berubah dari kamu. Masih gampang banget dibikin gemeteran."
    hide ratih
    hide santika senggool
    scene ratih sulit
    r "(aku sulit mengontrol emosi dan jantungku gak berhenti.. deg-degan)"
    hide ratih sulit
    $ renpy.movie_cutscene("heartbeats.webm")
    scene belina marah
    e "perasaan ratih pun sakit banget.."
    e "SUPEREGO dan ID bantu Ratih keluar dari sini!!"
    show expression Solid("#000000") as background_gelap:
        alpha 0.6
        size (1920,1080)
    show superego 1:
        zoom 0.8
        xalign 1.0
        yalign 0.9
    show id 3:
        zoom 0.8
        xalign 0.1
        yalign 0.8
    "SIAPP !!!"
    hide belina marah
    hide superego 1
    hide id 3
    show hitam3:
        fit "cover"
    r "(kabur)"
    play music "audio/tertawa.ogg"
    s "(tertawa)"
    hide santika senggool
    hide hitam3
    stop music fadeout 1.0
    scene ratih syok
    "dikamarnya..."
    "Ratih menangis melulu, rasanya kek ditusuk.."
    scene black with dissolve
    scene ratih mind world:
        fit "cover"
    e "ada apa ?"
    show heartwarm:
        fit "cover"
    r "gatau sih..."
    hide heartwarm
    scene belina tenang
    e "gak apa apa, ambil napas dulu.."
    show expression Solid("#000000") as background_gelap:
        alpha 0.8
        size (1920,1080)
    show superego 2:
        zoom 0.7
        xalign 1.0
        yalign 1.0
    p "apa dia lg down?"
    show id 3:
        zoom 0.7
        xalign 0.1
        yalign 1.0
    u "iyalah, masa km buta?"
    hide background_gelap
    hide belina
    hide ratih mind world
    scene black with dissolve
    scene eton teater:
        fit "cover"
    "Hari H pelaksanaan audisi dimulai"
    scene black with dissolve
    $ renpy.movie_cutscene("endinga.webm")
    scene ratih berat
    r "aku berani..."
    r "tapi rasanya berat sekali..."
    k "gapapa, pelan-pelan saja, stau per satu langkah saja.."
    r "..."
    hide ratih berat 
    scene ortu2
    i "ratih.. kamu sudah bisa berani.."
    a "uh... selamat?"
    a "selamat, nak. Sebelumnya maafkan ayah jika ada.."
    a "erm... tidak memerhatikanmu?"
    show expression Solid("#000000") as background_gelap:
        alpha 0.5
        size (1920,1080)
    show ratih end:
        zoom 0.7
        xalign 1.0
        yalign 1.0
    r "pah mah... terima kasih... (peluk)"
    r "gapapa sih, pah.."
    hide ratih end
    hide ortu2
    scene black with dissolve
    scene final1
    "Terima kasih sudah menjaga dan melindungi ego, Luna"
    scene final2
    "Hope you'd never give up"
    scene black with dissolve
    return